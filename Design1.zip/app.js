// AirPulse Mattress - E-Commerce Interactive Script

document.addEventListener('DOMContentLoaded', () => {
    // ----------------------------------------------------
    // 1. SCROLL PROGRESS & STICKY CHECKOUT BAR (DTC ALIGNMENT)
    // ----------------------------------------------------
    const scrollProgress = document.getElementById('scroll-progress');
    const stickyCheckout = document.querySelector('.sticky-checkout-bar');
    
    window.addEventListener('scroll', () => {
        const docHeight = document.documentElement.scrollHeight - window.innerHeight;
        const scrolled = (window.pageYOffset / docHeight) * 100;
        scrollProgress.style.width = scrolled + '%';
    });
    
    // Smooth slide-up entrance animation for sticky bar on load
    setTimeout(() => {
        if (stickyCheckout) {
            stickyCheckout.classList.add('visible');
        }
    }, 800);

    // ----------------------------------------------------
    // 2. DYNAMIC ARRIVAL DATE ESTIMATOR
    // ----------------------------------------------------
    function updateDeliveryDates() {
        const dateEl = document.getElementById('delivery-range');
        if (!dateEl) return;
        
        const today = new Date();
        const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
        
        // Express: today + 2 days to today + 4 days
        const minDeliv = new Date(today);
        minDeliv.setDate(today.getDate() + 2);
        
        const maxDeliv = new Date(today);
        maxDeliv.setDate(today.getDate() + 4);
        
        const formatStr = `${months[minDeliv.getMonth()]} ${minDeliv.getDate()} - ${months[maxDeliv.getMonth()]} ${maxDeliv.getDate()}`;
        dateEl.textContent = formatStr;
    }
    updateDeliveryDates();

    // ----------------------------------------------------
    // 3. COUNTDOWN TIMERS
    // ----------------------------------------------------
    function initCountdowns() {
        const timerValEl = document.querySelectorAll('.timer-val');
        if (timerValEl.length === 0) return;
        
        // Set initial timer: 2 hours, 14 minutes, 30 seconds
        let seconds = 2 * 60 * 60 + 14 * 60 + 30;
        
        const interval = setInterval(() => {
            if (seconds <= 0) {
                seconds = 2 * 60 * 60; // Loop countdown
            }
            seconds--;
            
            const hours = Math.floor(seconds / 3600);
            const minutes = Math.floor((seconds % 3600) / 60);
            const secs = seconds % 60;
            
            const hoursStr = String(hours).padStart(2, '0');
            const minsStr = String(minutes).padStart(2, '0');
            const secsStr = String(secs).padStart(2, '0');
            
            const timerContainer = document.querySelector('.urgency-timer');
            if (timerContainer) {
                const vals = timerContainer.querySelectorAll('.timer-val');
                if (vals.length >= 3) {
                    vals[0].textContent = hoursStr;
                    vals[1].textContent = minsStr;
                    vals[2].textContent = secsStr;
                }
            }
            
            // Sync with any promo ticker countdown
            const bannerTimer = document.getElementById('banner-countdown');
            if (bannerTimer) {
                bannerTimer.textContent = `${hoursStr}:${minsStr}:${secsStr}`;
            }
            
        }, 1000);
    }
    initCountdowns();

    // New Sticky bar countdown (exactly 3h, stored in localStorage)
    function initStickyTimer() {
        const timerEl = document.getElementById('sticky-timer-val');
        if (!timerEl) return;
        
        const THREE_HOURS_SECS = 3 * 60 * 60;
        let targetTimestamp = localStorage.getItem('sticky_timer_target');
        
        if (!targetTimestamp) {
            targetTimestamp = Date.now() + THREE_HOURS_SECS * 1000;
            localStorage.setItem('sticky_timer_target', targetTimestamp);
        } else {
            targetTimestamp = parseInt(targetTimestamp, 10);
            if (Date.now() >= targetTimestamp) {
                targetTimestamp = Date.now() + THREE_HOURS_SECS * 1000;
                localStorage.setItem('sticky_timer_target', targetTimestamp);
            }
        }
        
        const updateTimer = () => {
            let diffMs = targetTimestamp - Date.now();
            if (diffMs <= 0) {
                targetTimestamp = Date.now() + THREE_HOURS_SECS * 1000;
                localStorage.setItem('sticky_timer_target', targetTimestamp);
                diffMs = THREE_HOURS_SECS * 1000;
            }
            
            const diffSecs = Math.max(0, Math.floor(diffMs / 1000));
            const hours = Math.floor(diffSecs / 3600);
            const minutes = Math.floor((diffSecs % 3600) / 60);
            const seconds = diffSecs % 60;
            
            timerEl.textContent = `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
        };
        
        updateTimer();
        setInterval(updateTimer, 1000);
    }
    initStickyTimer();

    // Live visitor and checkout counters (Shopify animated counts)
    function initStickyCounters() {
        const checkoutEl = document.getElementById('checkout-count-val');
        if (checkoutEl) {
            let targetCheckouts = sessionStorage.getItem('sticky_checkouts');
            if (!targetCheckouts) {
                targetCheckouts = Math.floor(Math.random() * 3) + 1; // 1 to 3
                sessionStorage.setItem('sticky_checkouts', targetCheckouts);
            } else {
                targetCheckouts = parseInt(targetCheckouts, 10);
            }
            
            let current = 0;
            const checkInterval = setInterval(() => {
                if (current >= targetCheckouts) {
                    checkoutEl.textContent = targetCheckouts;
                    clearInterval(checkInterval);
                } else {
                    current++;
                    checkoutEl.textContent = current;
                }
            }, 150);
        }
        
        const visitorsEl = document.getElementById('visitors-count-val');
        if (visitorsEl) {
            let targetVisitors = sessionStorage.getItem('sticky_visitors');
            if (!targetVisitors) {
                targetVisitors = Math.floor(Math.random() * 11) + 30; // 30 to 40
                sessionStorage.setItem('sticky_visitors', targetVisitors);
            } else {
                targetVisitors = parseInt(targetVisitors, 10);
            }
            
            let current = 0;
            const duration = 1200;
            const stepTime = Math.max(Math.floor(duration / targetVisitors), 15);
            
            const visitInterval = setInterval(() => {
                if (current >= targetVisitors) {
                    visitorsEl.textContent = targetVisitors;
                    clearInterval(visitInterval);
                } else {
                    current += Math.ceil(targetVisitors / 30);
                    if (current >= targetVisitors) {
                        current = targetVisitors;
                    }
                    visitorsEl.textContent = current;
                }
            }, stepTime);
        }
        
        const stockEl = document.getElementById('stock-count-val');
        if (stockEl) {
            const currentStock = Math.floor(Math.random() * 9) + 12; // 12 to 20
            stockEl.textContent = currentStock;
        }
    }
    initStickyCounters();

    // CTA button custom click ripple effect and scroll
    function initStickyBuyButton() {
        const btn = document.getElementById('sticky-buy-now-btn');
        if (!btn) return;
        
        btn.addEventListener('click', (e) => {
            const x = e.clientX - btn.getBoundingClientRect().left;
            const y = e.clientY - btn.getBoundingClientRect().top;
            
            const rippleSpan = document.createElement('span');
            rippleSpan.classList.add('ripple');
            rippleSpan.style.left = `${x}px`;
            rippleSpan.style.top = `${y}px`;
            
            btn.appendChild(rippleSpan);
            setTimeout(() => { rippleSpan.remove(); }, 600);
            
            const targetSection = document.getElementById('bundle-selector');
            if (targetSection) {
                targetSection.scrollIntoView({ behavior: 'smooth' });
            }
        });
    }
    initStickyBuyButton();

    // ----------------------------------------------------
    // 4. DECAYING STOCK METER
    // ----------------------------------------------------
    function initStockMeter() {
        const stockCountEl = document.querySelector('.stock-left-count');
        const stockProgress = document.querySelector('.stock-progress');
        if (!stockCountEl || !stockProgress) return;
        
        let stockCount = 14;
        
        const interval = setInterval(() => {
            if (stockCount > 3) {
                stockCount -= Math.random() > 0.7 ? 1 : 0;
                stockCountEl.textContent = stockCount;
                
                // Adjust width proportionally from max 50 items
                const percentage = (stockCount / 50) * 100;
                stockProgress.style.width = percentage + '%';
            }
        }, 18000);
    }
    initStockMeter();

    // ----------------------------------------------------
    // 5. BEFORE VS AFTER INTERACTIVE SLIDER
    // ----------------------------------------------------
    const slider = document.querySelector('.before-after-slider');
    const afterImg = document.querySelector('.slider-img.after');
    const handle = document.querySelector('.slider-handle');
    
    if (slider && afterImg && handle) {
        let isDragging = false;
        
        const setSliderWidth = (xPos) => {
            const rect = slider.getBoundingClientRect();
            let offsetX = xPos - rect.left;
            
            if (offsetX < 0) offsetX = 0;
            if (offsetX > rect.width) offsetX = rect.width;
            
            const percentage = (offsetX / rect.width) * 100;
            afterImg.style.width = percentage + '%';
            handle.style.left = percentage + '%';
        };
        
        // Mouse Events
        handle.addEventListener('mousedown', (e) => {
            isDragging = true;
            e.preventDefault();
        });
        
        window.addEventListener('mouseup', () => {
            isDragging = false;
        });
        
        window.addEventListener('mousemove', (e) => {
            if (!isDragging) return;
            setSliderWidth(e.clientX);
        });
        
        // Touch Events
        handle.addEventListener('touchstart', (e) => {
            isDragging = true;
        });
        
        window.addEventListener('touchend', () => {
            isDragging = false;
        });
        
        window.addEventListener('touchmove', (e) => {
            if (!isDragging) return;
            if (e.touches.length > 0) {
                setSliderWidth(e.touches[0].clientX);
            }
        });
        
        // Click to slide
        slider.addEventListener('click', (e) => {
            if (e.target !== handle && !handle.contains(e.target)) {
                setSliderWidth(e.clientX);
            }
        });
    }

    // ----------------------------------------------------
    // 6. INTERACTIVE PRODUCT EXPLAINER TABS
    // ----------------------------------------------------
    const tabBtns = document.querySelectorAll('.explainer-tab-btn');
    const expTitle = document.getElementById('exp-title');
    const expDesc = document.getElementById('exp-desc');
    const expImg = document.getElementById('exp-img');
    
    const explainerData = {
        comfort: {
            title: "Multi-Chamber Smart Tension",
            desc: "Independent orthopedic zones adapt directly to your sleep posture. High-strength fiber coils support key pressure nodes in your spine and shoulders, ensuring full support whether you sleep on your side or back.",
            img: "assets/airpulse_hero.png"
        },
        pump: {
            title: "Internal Micro-Silent Pump",
            desc: "Inflates or deflates your mattress in under 120 seconds. Built-in ultra-quiet sound shielding ensures late-night pressure adjustments won't wake your partner. Easily dial in your firmness level.",
            img: "assets/airpulse_lifestyle.png"
        },
        durability: {
            title: "Puncture-Resistant Double PVC",
            desc: "Constructed with commercial-grade 0.45mm eco-PVC and an extra-thick flocked organic top coat. Resists claws, camping gravel, and standard wear-and-tear while retaining full pressure over multiple days.",
            img: "assets/airpulse_hero.png"
        },
        orthopedic: {
            title: "Instant Spine Re-alignment",
            desc: "Designed in collaboration with chiropractic specialists. The dual-chamber structure maintains continuous core stability, preventing sagging or bowing and offering true mattress firmness for morning relief.",
            img: "assets/airpulse_lifestyle.png"
        }
    };
    
    tabBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            tabBtns.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            
            const target = btn.dataset.tab;
            const data = explainerData[target];
            if (data && expTitle && expDesc && expImg) {
                expTitle.style.opacity = 0;
                expDesc.style.opacity = 0;
                expImg.style.opacity = 0;
                
                setTimeout(() => {
                    expTitle.textContent = data.title;
                    expDesc.textContent = data.desc;
                    expImg.src = data.img;
                    
                    expTitle.style.opacity = 1;
                    expDesc.style.opacity = 1;
                    expImg.style.opacity = 1;
                }, 200);
            }
        });
    });

    // ----------------------------------------------------
    // 7. BUNDLE SELECTOR & SAVINGS CALCULATOR
    // ----------------------------------------------------
    const bundleCards = document.querySelectorAll('.bundle-card');
    const upsellItems = document.querySelectorAll('.upsell-item');
    const upsellCheckboxes = document.querySelectorAll('.upsell-item input');
    
    // Output UI Elements
    const sumOriginal = document.getElementById('sum-original');
    const sumDiscount = document.getElementById('sum-discount');
    const sumTotal = document.getElementById('sum-total');
    const sumSavingsText = document.getElementById('sum-savings-text');
    const giftProgressFill = document.querySelector('.gift-progress-fill');
    const giftMilestoneText = document.querySelector('.gift-progress-milestone');
    const checkoutBarPrice = document.querySelector('.sticky-checkout-price-val');
    const checkoutBarSavings = document.querySelector('.sticky-checkout-savings');
    
    let basePrice = 199;
    let qty = 1;
    let discountPercent = 0;
    
    // Bundle Configs
    const bundleDetails = {
        '1': { price: 199, discount: 0, qty: 1 },
        '2': { price: 398, discount: 0.15, qty: 2 }, // 15% Off
        '3': { price: 597, discount: 0.30, qty: 3 }  // 30% Off
    };
    
    function calculateTotal() {
        const selectedBundleCard = document.querySelector('.bundle-card.selected');
        const selectedBundleVal = selectedBundleCard ? selectedBundleCard.dataset.bundle : '1';
        const bundle = bundleDetails[selectedBundleVal];
        
        let subtotalOriginal = bundle.price;
        let subtotalCurrent = bundle.price * (1 - bundle.discount);
        
        // Accessories
        upsellCheckboxes.forEach(checkbox => {
            if (checkbox.checked) {
                const price = parseFloat(checkbox.dataset.price);
                // Pillow / sheet applied per mattress quantity
                if (checkbox.dataset.multiply === "true") {
                    subtotalOriginal += price * bundle.qty;
                    subtotalCurrent += price * bundle.qty;
                } else {
                    subtotalOriginal += price;
                    subtotalCurrent += price;
                }
            }
        });
        
        const savings = subtotalOriginal - subtotalCurrent;
        
        // Update main calculator box
        if (sumOriginal) sumOriginal.textContent = `$${subtotalOriginal.toFixed(2)}`;
        if (sumDiscount) sumDiscount.textContent = `-$${savings.toFixed(2)}`;
        if (sumTotal) sumTotal.textContent = `$${subtotalCurrent.toFixed(2)}`;
        if (sumSavingsText) sumSavingsText.textContent = `You Save $${savings.toFixed(2)} Today`;
        
        // Update Sticky Checkout Bar
        if (checkoutBarPrice) checkoutBarPrice.textContent = `$${subtotalCurrent.toFixed(2)}`;
        if (checkoutBarSavings) checkoutBarSavings.textContent = `You Save $${savings.toFixed(2)}!`;
        
        // Update Free Gift Progress
        if (giftProgressFill && giftMilestoneText) {
            let percentage = 0;
            if (subtotalCurrent < 199) {
                percentage = 30;
                giftMilestoneText.textContent = "Add AirPulse Mattress for Free Carrying Bag";
                giftProgressFill.style.background = 'linear-gradient(90deg, var(--danger), var(--accent))';
            } else if (subtotalCurrent >= 199 && subtotalCurrent < 340) {
                percentage = 70;
                giftMilestoneText.textContent = "Carrying Bag unlocked! Add $140 more for Free Ortho Pillows";
                giftProgressFill.style.background = 'linear-gradient(90deg, var(--primary), var(--accent))';
            } else {
                percentage = 100;
                giftMilestoneText.textContent = "🎉 Free Carrying Case + Premium Pillows Unlocked!";
                giftProgressFill.style.background = 'linear-gradient(90deg, var(--primary), var(--success))';
            }
            giftProgressFill.style.width = percentage + '%';
        }
        
        // Add micro-glow animation to calc container
        const calcBox = document.querySelector('.calc-summary-box');
        if (calcBox) {
            calcBox.classList.add('glow');
            setTimeout(() => {
                calcBox.classList.remove('glow');
            }, 600);
        }
    }
    
    // Bundle card clicks
    bundleCards.forEach(card => {
        card.addEventListener('click', () => {
            bundleCards.forEach(c => c.classList.remove('selected'));
            card.classList.add('selected');
            calculateTotal();
        });
    });
    
    // Upsell checkbox clicks
    upsellItems.forEach(item => {
        item.addEventListener('click', (e) => {
            // Prevent double triggers if clicked directly on checkbox
            if (e.target.tagName !== 'INPUT') {
                const cb = item.querySelector('input');
                cb.checked = !cb.checked;
            }
            calculateTotal();
        });
    });
    
    // Initial Calc
    calculateTotal();

    // ----------------------------------------------------
    // 8. CUSTOMER VIDEO REVIEW CAROUSEL
    // ----------------------------------------------------
    const carousel = document.querySelector('.video-carousel');
    const nextBtn = document.querySelector('.carousel-nav-btn.next');
    const prevBtn = document.querySelector('.carousel-nav-btn.prev');
    
    if (carousel && nextBtn && prevBtn) {
        let offset = 0;
        const cardWidth = 324; // Width + margin gap
        
        nextBtn.addEventListener('click', () => {
            const maxScroll = carousel.scrollWidth - carousel.parentElement.clientWidth;
            offset += cardWidth;
            if (offset > maxScroll) offset = maxScroll;
            carousel.style.transform = `translateX(-${offset}px)`;
        });
        
        prevBtn.addEventListener('click', () => {
            offset -= cardWidth;
            if (offset < 0) offset = 0;
            carousel.style.transform = `translateX(-${offset}px)`;
        });
    }

    // ----------------------------------------------------
    // 9. REVIEWS AUTO-ROTATING SLIDER
    // ----------------------------------------------------
    const testimonialSlides = document.querySelectorAll('.testimonial-slide');
    if (testimonialSlides.length > 0) {
        let currentSlide = 0;
        
        setInterval(() => {
            testimonialSlides[currentSlide].classList.remove('active');
            currentSlide = (currentSlide + 1) % testimonialSlides.length;
            testimonialSlides[currentSlide].classList.add('active');
        }, 6000);
    }

    // ----------------------------------------------------
    // 10. FAQ ACCORDION WITH LIVE SEARCH
    // ----------------------------------------------------
    const faqHeaders = document.querySelectorAll('.faq-header');
    const searchInput = document.getElementById('faq-search');
    const faqItems = document.querySelectorAll('.faq-item');
    
    faqHeaders.forEach(header => {
        header.addEventListener('click', () => {
            const item = header.parentElement;
            const body = item.querySelector('.faq-body');
            
            const isOpen = item.classList.contains('open');
            
            // Close other items
            document.querySelectorAll('.faq-item').forEach(el => {
                el.classList.remove('open');
                el.querySelector('.faq-body').style.maxHeight = '0';
            });
            
            if (!isOpen) {
                item.classList.add('open');
                body.style.maxHeight = body.scrollHeight + 'px';
            }
        });
    });
    
    if (searchInput) {
        searchInput.addEventListener('input', (e) => {
            const query = e.target.value.toLowerCase().trim();
            
            faqItems.forEach(item => {
                const question = item.querySelector('.faq-header h4').textContent.toLowerCase();
                const answer = item.querySelector('.faq-body p').textContent.toLowerCase();
                
                if (question.includes(query) || answer.includes(query)) {
                    item.style.display = 'block';
                } else {
                    item.style.display = 'none';
                }
            });
        });
    }

    // ----------------------------------------------------
    // 11. RECENT PURCHASE NOTIFICATIONS TICKER
    // ----------------------------------------------------
    const notification = document.getElementById('purchase-notif');
    const notifText = document.getElementById('notif-text');
    const notifProduct = document.getElementById('notif-product');
    const notifTime = document.getElementById('notif-time');
    
    const recentBuyers = [
        { name: "John S. from Chicago, IL", product: "AirPulse Pro Bundle (Save 15%)", time: "2 minutes ago" },
        { name: "Sarah K. from Austin, TX", product: "AirPulse Luxe Mattress (Ortho Premium)", time: "Just now" },
        { name: "Michael T. from New York, NY", product: "2x AirPulse Lite Mattress Pack", time: "5 minutes ago" },
        { name: "Emily D. from Seattle, WA", product: "AirPulse Luxe Sleep-Smart Bundle", time: "1 minute ago" },
        { name: "David L. from Denver, CO", product: "AirPulse Pro Mattress + Fitted Sheet", time: "4 minutes ago" }
    ];
    
    function triggerNotification() {
        if (!notification || recentBuyers.length === 0) return;
        
        const randomBuyer = recentBuyers[Math.floor(Math.random() * recentBuyers.length)];
        notifText.innerHTML = `<strong>${randomBuyer.name}</strong> bought`;
        notifProduct.textContent = randomBuyer.product;
        notifTime.textContent = randomBuyer.time;
        
        notification.classList.add('active');
        
        setTimeout(() => {
            notification.classList.remove('active');
        }, 6000);
    }
    
    // Loop every 22 seconds
    setTimeout(triggerNotification, 4000);
    setInterval(triggerNotification, 22000);



    // ----------------------------------------------------
    // 13. FLOATING WHATSAPP / HELP HUB MENU
    // ----------------------------------------------------
    const waBtn = document.querySelector('.floating-btn.whatsapp');
    if (waBtn) {
        waBtn.addEventListener('click', () => {
            alert("Connecting to AirPulse Live sleep consultant support chat... (WhatsApp demo trigger)");
            window.open("https://wa.me/1234567890", "_blank");
        });
    }
    
    // ----------------------------------------------------
    // 14. VIDEO REVIEW MODAL TRIGGER
    // ----------------------------------------------------
    const videoCards = document.querySelectorAll('.video-card');
    videoCards.forEach(card => {
        card.addEventListener('click', () => {
            const reviewer = card.querySelector('.video-reviewer-name').textContent;
            const text = card.querySelector('.video-review-text').textContent;
            
            alert(`Review Video Demo Playback Mode:\n\nReviewer: ${reviewer}\nReview Quote: "${text}"\n\n(Playing High-converting User Generated Content review...)`);
        });
    });
    
    // Sticky coupon indicator click
    const couponIndicator = document.querySelector('.floating-btn.coupon-indicator');
    if (couponIndicator) {
        couponIndicator.addEventListener('click', () => {
            alert("AirPulse Premium Special: Save an extra $15 on Pro & Luxe setups by ordering in the next hour!");
        });
    }
});
